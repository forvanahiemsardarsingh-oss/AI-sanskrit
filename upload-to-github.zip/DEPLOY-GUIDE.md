# Deploy to GitHub Pages

This folder is ready to deploy to GitHub Pages for a free, fast install link.

## 🚀 Quick Deploy (2 minutes)

### Step 1: Create GitHub Repository
1. Go to https://github.com/new
2. Name it `vachas-ai-install`
3. Make it **Public**
4. Click **Create repository**

### Step 2: Upload Files
**Option A: Drag & Drop**
1. Open your new repo on GitHub
2. Click **"uploading an existing file"**
3. Drag these files/folders:
   - `install.html`
   - `APK-README.md`
   - `netlify.toml`
4. Click **Commit changes**

**Option B: Command Line**
```bash
cd "vachas-ai-apk"
git init
git add install.html APK-README.md netlify.toml .github
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vachas-ai-install.git
git push -u origin main
```

### Step 3: Enable GitHub Pages
1. Go to repo **Settings** → **Pages**
2. Under **Source**, select **GitHub Actions**
3. The workflow will run automatically
4. Wait 1-2 minutes for deployment

### Step 4: Get Your Link
Your install page will be at:
```
https://YOUR_USERNAME.github.io/vachas-ai-install/install.html
```

## 🎉 Share the Link

Once deployed, share this URL with anyone:
- **Email/SMS**: Send the link
- **QR Code**: Visit the page and scan the QR
- **Social**: Post the link anywhere

## 🔄 Updating

To update the page later:
1. Edit `install.html`
2. Push to GitHub
3. Changes go live in ~1 minute

---

**Free hosting** • **SSL included** • **Works worldwide**
